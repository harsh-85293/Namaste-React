const Footer = () => {
    return (
        <div className="Footer">
            <h1>Welcome to Foodigo App!!!</h1>
        </div>
    )
}

export default Footer;