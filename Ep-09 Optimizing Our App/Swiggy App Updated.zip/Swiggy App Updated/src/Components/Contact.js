const Contact = () => {
    return(
        <div>
            <h1>Contact Us</h1>
            <h2>+918529373955</h2>
        </div>
    );
}

export default Contact;