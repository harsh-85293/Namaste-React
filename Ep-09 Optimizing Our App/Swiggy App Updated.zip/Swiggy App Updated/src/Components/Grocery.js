
const Grocery = ()=>{
    return(
        <div>
            <h1>
                Our grocery store, and we have a lot of child components inside this web pages!!!
            </h1>
        </div>
    );
}

export default Grocery;